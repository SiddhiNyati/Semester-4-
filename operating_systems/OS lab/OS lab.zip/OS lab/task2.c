// Task 2
#include <stdio.h>

int main() {
    int arr[5] = {1, 2, 3, 4, 5};

    printf("Address of arr: %p\n", (void*)arr);

    return 0;
}
